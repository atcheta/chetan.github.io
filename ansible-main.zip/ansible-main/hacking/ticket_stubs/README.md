What's this?

This is a directory of common responses to save some typing when responding to GitHub tickets to avoid
some carpal tunnel syndrome events as Ansible maintainers deal with the ticket influx.

They are present in the project git repo (on GitHub) so it's easy for people to share and update these snippets of text.
