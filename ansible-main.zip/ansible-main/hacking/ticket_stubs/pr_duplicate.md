Hi!

Thanks very much for your submission to Ansible.  It means a lot to us that you've taken time to contribute.

It looks like the work from this pull request is a duplicate of the following PR(s):

* INSERT PR(S) HERE

Based on this, we are going to close this PR in favor of the above as a consolidated location to keep track of the issue.

However, we're absolutely always up for discussion.
In the future, sometimes starting a discussion on the development list prior to implementing a feature
 can make getting things included a little easier, but it's not always necessary.

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
If you or anyone else has any further questions, please let us know by using any of the communication methods listed in the page below:

* <https://docs.ansible.com/ansible/latest/community/communication.html>

Thank you once again for this and your interest in Ansible!
